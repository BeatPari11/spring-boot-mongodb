package com.medical.mdbspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MdbSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
